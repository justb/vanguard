'use strict';

module.exports = function IndexModel() {
    return {
        name: 'index'
    };
};
